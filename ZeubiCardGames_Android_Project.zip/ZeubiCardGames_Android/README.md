# ZeubiCardGames Android V1

Application Android hors ligne basée sur `ZeubiCardGames_V6_2_StableAssets.html`.

## Générer l'APK
1. Ouvrir ce dossier dans Android Studio.
2. Attendre la synchronisation Gradle.
3. Menu **Build > Build APK(s)**.
4. APK généré dans `app/build/outputs/apk/debug/app-debug.apk`.

Configuration : Android 7.0 minimum, plein écran immersif, orientation paysage, stockage local WebView activé.
