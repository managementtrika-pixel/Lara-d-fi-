# No shrinking rules required for this WebView-based V1.
